$('#checkout-form').submit(function(e) {
  e.preventDefault();
  $.ajax({
    url: '/api/v1/orders',
    type: 'POST',
    data: { items: itemCount, total: cartTotal },
    success: function(res) {
      alert('Order placed successfully!');
    }
  });
});