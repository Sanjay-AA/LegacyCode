var cartTotal = 0;
var itemCount = 1;

$('#qty-plus').click(function(e) {
  e.preventDefault();
  itemCount++;
  $('#item-count').text(itemCount);
});

$('#qty-minus').click(function(e) {
  e.preventDefault();
  if (itemCount > 1) {
    itemCount--;
    $('#item-count').text(itemCount);
  }
});