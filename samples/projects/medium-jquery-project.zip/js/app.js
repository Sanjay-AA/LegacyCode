$(document).ready(function() {
  console.log('App initialized');
  var userSession = localStorage.getItem('user_session');
  if (userSession) {
    $('#user-banner').text('Welcome back');
  }
});